# scripts/install_dependencies
#!/bin/bash
sudo echo 1 >/proc/sys/vm/drop_caches
