#!/bin/bash
tomcatup
