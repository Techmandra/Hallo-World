# scripts/start_server
#!/bin/bash
sudo -i
tomcatup
